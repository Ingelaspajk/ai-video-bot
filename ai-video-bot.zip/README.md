
# AI Video Bot

AI Video Bot är en applikation som genererar animerade videor baserade på textbeskrivningar med hjälp av generativ AI-teknologi, som Stable Diffusion.

## Funktioner
- Skapa animerade videor från textprompter.
- Rendera videor i upp till 4K-upplösning.
- Hantera förfrågningar via ett Flask API.
- Skalbart och anpassningsbart för molnlagring och frontend-integration.

## Installation

### 1. Klona detta repository
```bash
git clone https://github.com/Ingelaspajk/ai-video-bot.git
cd ai-video-bot
```

### 2. Installera beroenden
```bash
pip install -r requirements.txt
```

### 3. Kör applikationen
```bash
python app.py
```

API:t körs nu på `http://127.0.0.1:5000`.

## API-användning
### POST /generate
Skapa en video baserat på en textprompt.
