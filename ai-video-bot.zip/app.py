
from flask import Flask, request, jsonify, send_file
from video_generator import generate_frames, create_video_from_frames
from cloud_storage import upload_to_s3
import os

app = Flask(__name__)

@app.route('/generate', methods=['POST'])
def generate():
    data = request.json
    prompt = data.get('prompt')
    num_frames = int(data.get('frames', 10))
    try:
        frames = generate_frames(prompt, num_frames)
        video_file = create_video_from_frames(frames)
        bucket_name = "my-ai-videos"
        video_url = upload_to_s3(video_file, bucket_name)
        for frame in frames:
            os.remove(frame)
        os.remove(video_file)
        return jsonify({"video_url": video_url})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
