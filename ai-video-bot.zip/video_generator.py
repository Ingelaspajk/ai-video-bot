
from diffusers import StableDiffusionPipeline
from moviepy.editor import ImageSequenceClip
import os

pipe = StableDiffusionPipeline.from_pretrained("runwayml/stable-diffusion-v1-5")
pipe.to("cuda")

def generate_frames(prompt, num_frames=10, resolution=(512, 512)):
    frames = []
    for i in range(num_frames):
        image = pipe(prompt).images[0]
        file_name = f"static/frame_{i}.png"
        image.save(file_name)
        frames.append(file_name)
    return frames

def create_video_from_frames(frames, output_file="static/generated_video.mp4", fps=24):
    clip = ImageSequenceClip(frames, fps=fps)
    clip.write_videofile(output_file, codec="libx264", bitrate="5000k")
    return output_file
